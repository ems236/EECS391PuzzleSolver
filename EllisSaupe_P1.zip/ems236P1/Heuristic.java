public interface Heuristic 
{
	public double calculate(State state);
	public String getName();
}
