public class Solution 
{
	public int depth;
	public int nodesExplored;
	
	public Solution(int depth, int nodesExplored)
	{
		this.depth = depth;
		this.nodesExplored = nodesExplored;
	}
}
